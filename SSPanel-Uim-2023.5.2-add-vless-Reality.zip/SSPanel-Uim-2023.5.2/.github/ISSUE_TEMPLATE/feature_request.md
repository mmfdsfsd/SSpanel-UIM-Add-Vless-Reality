---
name: Feature request
about: Suggest a new idea for this project
title: "[Feature Request] 在这里填入你所希望添加功能的概述"
labels: feature-request

---

**Feature 功能请求**

Describe the feature you want. 请描述你想要的功能。
