<?php

declare(strict_types=1);

/**
 * To define global variable
 */

const BASE_PATH = __DIR__ . '/..';
const VERSION = '2023.5';
